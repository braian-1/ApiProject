using apiWeb.Application.Services;
using apiWeb.Domain.Models;
using Microsoft.AspNetCore.Mvc;

namespace apiWeb.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class CustomerController : ControllerBase
{
    private readonly CustomerService _customerService;

    public CustomerController(CustomerService customerService)
    {
        _customerService = customerService;
    }

    [HttpGet]
    public async Task<IActionResult> GetAllCustomersAsync()
    {
        var customers = await _customerService.GetAll();
        return Ok(customers);
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> GetCustomerById(int id)
    {
        var customer =  await _customerService.GetById(id);
        return Ok(customer);
    }

    [HttpPost]
    public async Task<IActionResult> AddCustomers(Customers customer)
    {
        await _customerService.Add(customer);
        return Ok(customer);
    }
    
    [HttpPut]
    [Route("{id}")]
    public async Task<IActionResult> UpdateCustomers(int id, [FromBody] Customers customers)
    {
        customers.Id = id;
        await _customerService.Update(customers);
        return Ok(customers);
    }

    [HttpDelete]
    [Route("{id}")]
    public async Task<IActionResult> DeleteCustomers(int id)
    {
        await _customerService.Delete(id);
        return Ok();
    }
}