using apiWeb.Application.Services;
using apiWeb.Domain.Models;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;

namespace apiWeb.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ProductController :  ControllerBase
{
    public readonly ProductService _productService;
    
    public ProductController(ProductService productService)
    {
        _productService = productService;
    }

    [HttpGet]
    public async Task<IActionResult> GetAll()
    {
        var products = await _productService.GetAll();
        return Ok(products);
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> GetById(int id)
    {
        var product = await _productService.GetById(id);
        return Ok(product);
    }

    [HttpPost]
    public async Task<IActionResult> Add(Product product)
    {
        await _productService.Add(product);
        return Ok(product);
    }

    [HttpPut]
    [Route("{id}")]
    public async Task<IActionResult> Update(int id,[FromBody] Product product)
    {
        product.Id = id;
        await _productService.Update(product);
        return Ok(product);
    }

    [HttpDelete]
    [Route("{id}")]
    public async Task<IActionResult> Delete(int id, ProductService productService)
    {
        await _productService.Delete(id);
        return Ok();
    }
}