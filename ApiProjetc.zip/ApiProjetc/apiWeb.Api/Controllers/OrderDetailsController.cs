using apiWeb.Application.Services;
using apiWeb.Domain.Models;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;

namespace apiWeb.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class OrderDetailsController :  ControllerBase
{
    private readonly OrderDetailsService _orderDetailsService;

    public OrderDetailsController(OrderDetailsService orderDetailsService)
    {
        _orderDetailsService = orderDetailsService;
    }

    [HttpGet]
    public async Task<IActionResult> GetAll()
    {
        var orderDetails = await _orderDetailsService.GetAll();
        return Ok(orderDetails);
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> GetById(int id)
    {
        var orderDetails = await _orderDetailsService.GetById(id);
        return Ok(orderDetails);
    }

    [HttpPost]
    public async Task<IActionResult> Add(OrderDetails orderDetails)
    {
        await _orderDetailsService.Add(orderDetails);
        return Ok(orderDetails);
    }

    [HttpPut]
    [Route("{id}")]
    public async Task<IActionResult> Update(int id,[FromBody] OrderDetails orderDetails)
    {
        orderDetails.Id = id;
        await _orderDetailsService.Update(orderDetails);
        return Ok(orderDetails);
    }

    [HttpDelete]
    [Route("{id}")]
    public async Task<IActionResult> Delete(int id)
    {
        await _orderDetailsService.Delete(id);
        return Ok();
    }
}