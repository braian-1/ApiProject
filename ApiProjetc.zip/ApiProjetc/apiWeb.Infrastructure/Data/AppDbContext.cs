using apiWeb.Domain.Models;
using Microsoft.EntityFrameworkCore;

namespace apiWeb.Infrastructure.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }
    
    public DbSet<Customers> Customer { get; set; }
    public DbSet<Order> Orders {get; set;}
    public DbSet<OrderDetails> OrderDetail {get; set;}
    public DbSet<Product> Products {get; set;}
    
}