using apiWeb.Domain.Models;
using apiWeb.Domain.Repositories;
using apiWeb.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace apiWeb.Infrastructure.Repositories;

public class OrderDetailsRepositories : IOrderDetailsRepository
{
    private readonly AppDbContext _context;
    public OrderDetailsRepositories(AppDbContext context)
    {
        _context = context;
    }
    
    public async Task<OrderDetails> GetByIdAsync(int id)
    {
        return await _context.OrderDetail.FindAsync(id);
    }

    public async Task<IEnumerable<OrderDetails>> GetAllAsync()
    {
        return await _context.OrderDetail.ToListAsync();
    }

    public async Task AddAsync(OrderDetails orderDetails)
    {
        _context.OrderDetail.Add(orderDetails);
        await _context.SaveChangesAsync();
    }

    public async Task UpdateAsync(OrderDetails orderDetails)
    {
        _context.OrderDetail.Update(orderDetails);
        await _context.SaveChangesAsync();
    }

    public async Task DeleteAsync(int id)
    {
        var existing = await _context.OrderDetail.FindAsync(id);
        if (existing != null)
        {
            _context.OrderDetail.Remove(existing);
            await _context.SaveChangesAsync();
        }
    }
}