using apiWeb.Domain.Models;
using apiWeb.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using apiWeb.Domain.Repositories;

namespace apiWeb.Infrastructure.Repositories;

public class CustomerRepositories : ICustomerRepository
{
    private readonly AppDbContext _context;
    public CustomerRepositories(AppDbContext context)
    {
        _context = context;
    }
    
    public async Task<Customers> GetByIdAsync(int id)
    {
        return await _context.Customer.FindAsync(id);
    }

    public async Task<IEnumerable<Customers>> GetAllAsync()
    {
        return await _context.Customer.ToListAsync();
    }

    public async Task AddAsync(Customers customers)
    {
        _context.Customer.Add(customers);
        await _context.SaveChangesAsync();
    }

    public async Task UpdateAsync(Customers customers)
    {
        await _context.SaveChangesAsync();
    }

    public async Task DeleteAsync(int id)
    {
        var existing = await _context.Customer.FindAsync(id);
        if (existing != null)
        {
            _context.Customer.Remove(existing);
            await _context.SaveChangesAsync();
        }
    }
}

