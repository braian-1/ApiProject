using apiWeb.Domain.Models;
using apiWeb.Domain.Repositories;
using apiWeb.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace apiWeb.Infrastructure.Repositories;

public class ProductRepositories : IProductRepository
{
    private readonly AppDbContext _context;

    public ProductRepositories(AppDbContext context)
    {
        _context = context;
    }
    
    public async Task<Product> GetByIdAsync(int id)
    {
        return await _context.Products.FindAsync(id);
    }

    public async Task<IEnumerable<Product>> GetAllAsync()
    {
        return await _context.Products.ToListAsync();
    }

    public async Task AddAsync(Product product)
    {
        _context.Products.Add(product);
        await _context.SaveChangesAsync();
    }

    public async Task UpdateAsync(Product product)
    {
        _context.Products.Update(product);
        await _context.SaveChangesAsync();
    }

    public async Task DeleteAsync(int id)
    {
        var existing = await _context.Products.FindAsync(id);
        if (existing != null)
        {
            _context.Products.Remove(existing);
            await _context.SaveChangesAsync();
        }
    }
}