namespace apiWeb.Domain.Models;

public class Customers
{
    public int Id { get; set; }
    public string Name { get; set; } = String.Empty;
    public string Email { get; set; } = String.Empty;
    
    public ICollection<OrderDetails> OrderDetails { get; set; }
}