using apiWeb.Domain.Models;

namespace apiWeb.Domain.Repositories;

public interface IOrderDetailsRepository
{
    Task<OrderDetails> GetByIdAsync(int id);
    Task<IEnumerable<OrderDetails>> GetAllAsync();
    Task AddAsync(OrderDetails orderDetails);
    Task UpdateAsync(OrderDetails orderDetails);
    Task DeleteAsync(int id);
}