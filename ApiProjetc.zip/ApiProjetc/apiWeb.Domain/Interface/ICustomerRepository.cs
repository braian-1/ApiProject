using apiWeb.Domain.Models;

namespace apiWeb.Domain.Repositories;

public interface ICustomerRepository
{
    Task<Customers> GetByIdAsync(int id);
    Task<IEnumerable<Customers>> GetAllAsync();
    Task AddAsync(Customers customers);
    Task UpdateAsync(Customers customers);
    Task DeleteAsync(int id);
}