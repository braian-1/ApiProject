using apiWeb.Domain.Models;
using apiWeb.Domain.Repositories;

namespace apiWeb.Application.Services;

public class CustomerService
{
    private readonly ICustomerRepository _repository;

    public CustomerService(ICustomerRepository customerRepository)
    {
        _repository = customerRepository;
    }

    public async Task<IEnumerable<Customers>> GetAll()
    {
        return await _repository.GetAllAsync();
    }

    public async Task<Customers> GetById(int id)
    {
        var customer = await _repository.GetByIdAsync(id);
        if (customer == null)
        {
            throw new KeyNotFoundException($"El cliente con el ID {id} no se ha encontrado");
        }
        return await _repository.GetByIdAsync(id);
    } 

    public async Task Add(Customers customer)
    {
        if (string.IsNullOrWhiteSpace(customer.Email))
            throw new ArgumentException("El emial es obligatorio");
        
        await _repository.AddAsync(customer);
    }

    public async Task Delete(int id)
    {
        var customer = await _repository.GetByIdAsync(id);
        if (customer == null)
        {
            throw new KeyNotFoundException($"El cliente con el ID {id} no se ha podido encontrar");
        }
        await _repository.DeleteAsync(id);
    }

    public async Task Update(Customers customer)
    {
        await _repository.UpdateAsync(customer);
    }
}