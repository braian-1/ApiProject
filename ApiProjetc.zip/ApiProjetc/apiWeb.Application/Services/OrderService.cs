using apiWeb.Domain.Models;
using apiWeb.Domain.Repositories;

namespace apiWeb.Application.Services;

public class OrderService
{
    private readonly IOrderRepository _repository;
    public OrderService(IOrderRepository repository)
    {
        _repository = repository;
    }

    public async Task<IEnumerable<Order>> GetAll()
    {
        return await _repository.GetAllAsync();
    }

    public async Task<Order> GetById(int id)
    {
        var order = await _repository.GetByIdAsync(id);
        if (order == null)
        {
            throw new KeyNotFoundException($"La orden con el ID {id} no se ha encontrado");
        }
        return await _repository.GetByIdAsync(id);
    }

    public async Task Add(Order order)
    {
        await _repository.AddAsync(order);
    }
    
    public async Task Update(Order order)
    {
        await _repository.UpdateAsync(order);
    }

    public async Task Delete(int id)
    {
        var order = await _repository.GetByIdAsync(id);
        if (order == null)
        {
            throw new KeyNotFoundException($"La orden con el ID {id} no se ha encontrado");
        }
        await _repository.DeleteAsync(id);
    }
}