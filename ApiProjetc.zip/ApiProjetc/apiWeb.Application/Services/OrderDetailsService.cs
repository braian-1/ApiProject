using apiWeb.Domain.Models;
using apiWeb.Domain.Repositories;

namespace apiWeb.Application.Services;

public class OrderDetailsService
{
    private readonly IOrderDetailsRepository _repository;
    
    public OrderDetailsService(IOrderDetailsRepository repository)
    {
        _repository = repository;
    }

    public async Task<IEnumerable<OrderDetails>> GetAll()
    {
        return await _repository.GetAllAsync();
    }

    public async Task<OrderDetails> GetById(int id)
    {
        var orderDetails = await _repository.GetByIdAsync(id);
        if (orderDetails == null)
        {
            throw new KeyNotFoundException($"La orden con el ID {id} no se ha encontrado");
        }
        return await _repository.GetByIdAsync(id);
    }

    public async Task Add(OrderDetails orderDetails)
    {
        await _repository.AddAsync(orderDetails);
    }

    public async Task Update(OrderDetails orderDetails)
    {
        await _repository.UpdateAsync(orderDetails);
    }

    public async Task Delete(int id)
    {
        var customer = await _repository.GetByIdAsync(id);
        if (customer == null)
        {
            throw new KeyNotFoundException($"La orden con el ID {id} no se ha encontrado");
        }
        await _repository.DeleteAsync(id);
    }
}