using apiWeb.Domain.Models;
using apiWeb.Domain.Repositories;

namespace apiWeb.Application.Services;

public class ProductService
{
    private readonly IProductRepository _repository;
    public ProductService(IProductRepository repository)
    {
        _repository = repository;
    }

    public async Task<IEnumerable<Product>> GetAll()
    {
        return await _repository.GetAllAsync();
    }

    public async Task<Product> GetById(int id)
    {
        var product = await _repository.GetByIdAsync(id);
        if (product == null)
        {
            throw new KeyNotFoundException($"El producto con ese ID {id} no se ha encontrado");
        }
        return await _repository.GetByIdAsync(id);
    }

    //El ArgumentException es cuando un parametro tiene valor nulo,vacio o fuera de rango
    //en el metodo de abajo seria si el precio es menor a 0 saldria el error
    public async Task Add(Product product)
    {
        if (product.Price < 0)
        {
            throw new ArgumentException("El precio ingresado no es valido");
        }
        await _repository.AddAsync(product);
    }
    
    public async Task Update(Product product)
    {
        await _repository.UpdateAsync(product);
    }

    //KeyNotFoundException sirve para indicar que si no se encontro una clave en especifico en una coleccion se ejecutara un error
    //Por ejemplo buscar el producto en la base de datos y que no exista
    public async Task Delete(int id)
    {
        var product = await _repository.GetByIdAsync(id);
        if (product == null)
        {
            throw new KeyNotFoundException($"El producto con el ID {id} no se ha podido encontrar");
        }
        await _repository.DeleteAsync(id);
    }
}